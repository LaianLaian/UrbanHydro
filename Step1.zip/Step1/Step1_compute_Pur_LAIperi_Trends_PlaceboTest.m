% This script computes linear trends and significance (p‑values) of
% urban precipitation (Pur) (Fig.1a)and peri‑urban LAI (LAIperi)(Fig.1b) over 2000–2021
% for 1,029 cities (peri-urban areas), and writes results to Excel files.
% And this script also apply placebo test for Fig.1d.
% It standardizes precipitation and LAI data, fits a panel OLS, and
% performs 1,000 permutations to derive empirical confidence intervals.

% NOTE:
% The data of precipitation and leaf area index (LAI) were imported into ArcGIS.
% Using the Zonal Statistics as Table tool, annual mean urban precipitation (peri‑urban LAI) values
% for each city (peri-urban zone) (2000–2021)
% were extracted and recorded in the "Pur" ("LAiperi") sheet of: 
% G:\Code\Result_Value.xlsx
%% Fig. 1a |  Urban precipitation (Pur) trend & significance
clear; clc
% Input and output settings
inputFile = 'G:\Code\Result_Value.xlsx';
inputSheet = 'Pur';
outputFile = 'G:\Code\Result_Trend.xlsx';
outputSheet = 'Pur_trend';

% Define analysis period and dimensions
years = 2000:2021;
numSites = 1029;
numYears = numel(years);
startCol = 3;  % Column 3 corresponds to year 2000

% Read data table
opts = detectImportOptions(inputFile, 'Sheet',  inputSheet);
opts.VariableNamesRange = 'A1:X1';  % Header row
opts.DataRange = 'A2';              % Data begins
dataTable = readtable(inputFile, opts,'Sheet',  inputSheet);

% Extract annual precipitation data (columns 2000–2021)
dataPur = table2array(dataTable(:, startCol:(startCol + numYears - 1)));

% Preallocate arrays for trend and p-value results
trendsPur = zeros(numSites, 1);
pValuesPur = zeros(numSites, 1);

% Perform linear regression for each city
for s = 1:numSites
    y = dataPur(s, :)';                    % Pur time series
    X = [ones(numYears, 1), years'];       % Design matrix for linear regression

    % Estimate linear trend (slope) using polyfit
    pFit = polyfit(years, y', 1);
    trendsPur(s) = pFit(1);

    % Estimate significance (p-value) using ordinary least squares
    [~, ~, ~, ~, stats] = regress(y, X);
    pValuesPur(s) = stats(3);              % Extract p-value
end

% Create output table including IDs
outputTable = table( ...
    dataTable.ID, ...
    trendsPur, ...
    pValuesPur, ...
    'VariableNames', {'SiteID', 'Trend_Pur', 'PValue_Pur'});

writetable(outputTable, outputFile, 'Sheet', outputSheet, 'WriteMode', 'overwritesheet');
fprintf('Urban precipitation trends saved to %s (sheet: %s)\n', outputFile, outputSheet);


%% Fig. 1b |  Peri‑urban LAI (LAIperi) trend & significance
clear; clc
% Input and output settings
inputFile = 'G:\Code\Result_Value.xlsx';
inputSheet = 'LAIperi';
outputFile = 'G:\Code\Result_Trend.xlsx';
outputSheet = 'LAIperi_trend';

% Define analysis period and dimensions
years = 2000:2021;
numSites = 1029;
numYears = numel(years);
startCol = 3;  % Column 3 corresponds to year 2000

% Read data table
opts = detectImportOptions(inputFile, 'Sheet',  inputSheet);
opts.VariableNamesRange = 'A1:X1';  % Header row
opts.DataRange = 'A2';              % Data begins
dataTable = readtable(inputFile, opts,'Sheet',  inputSheet);

% Extract annual peri-urban LAI data (columns 2000–2021)
dataLAIperi = table2array(dataTable(:, startCol:(startCol + numYears - 1)));

% Preallocate arrays for trend and p-value results
trendsLAIperi = zeros(numSites, 1);
pValuesLAIperi = zeros(numSites, 1);

% Perform linear regression for each peri-urban area
for s = 1:numSites
    y = dataLAIperi(s, :)';                % LAIperi time series
    X = [ones(numYears, 1), years'];       % Design matrix for linear regression

    % Estimate linear trend (slope) using polyfit
    pFit = polyfit(years, y', 1);
    trendsLAIperi(s) = pFit(1);

    % Estimate significance (p-value) using ordinary least squares
    [~, ~, ~, ~, stats] = regress(y, X);
    pValuesLAIperi(s) = stats(3);              % Extract p-value
end

% Create output table including IDs
outputTable = table( ...
    dataTable.ID, ...
    trendsLAIperi, ...
    pValuesLAIperi, ...
    'VariableNames', {'SiteID', 'Trend_LAIperi', 'PValue_LAIperi'});

writetable(outputTable, outputFile, 'Sheet', outputSheet, 'WriteMode', 'overwritesheet');
fprintf('Peri‑urban LAIperi trends saved to %s (sheet: %s)\n', outputFile, outputSheet);

%% Fig. 1d |  Placebo test for Pur & LAIperi
clear; clc;
rng('default');  % For reproducibility of random permutations

% Parameters
years = 2000:2021;
num_years = numel(years);
num_sites = 1029;
num_placebo = 1000;
conf_level = 0.95;

% Input Excel file
inputFile = 'G:\Code\Result_Value.xlsx';

% Read Pur data
opts = detectImportOptions(inputFile, 'Sheet', 'Pur');
opts.VariableNamesRange = 'A1:X1';
opts.DataRange = 'A2';
dataTable_Pur = readtable(inputFile, opts, 'Sheet', 'Pur');
Pur_data = table2array(dataTable_Pur(:, 3:end))';  % Transpose: years × city

% Read LAIperi data
opts = detectImportOptions(inputFile, 'Sheet', 'LAIperi');
opts.VariableNamesRange = 'A1:X1';
opts.DataRange = 'A2';
dataTable_LAIperi = readtable(inputFile, opts, 'Sheet', 'LAIperi');
LAIperi_data = table2array(dataTable_LAIperi(:, 3:end))';

% Z-score normalization
standardized_Pur = normalize(Pur_data, 1);
standardized_LAIperi = normalize(LAIperi_data, 1);
Pur_vector = standardized_Pur(:);
LAIperi_vector = standardized_LAIperi(:);

% Panel regression
model = fitlm(LAIperi_vector, Pur_vector, 'Intercept', true);
beta = model.Coefficients.Estimate;

% Placebo test
perm_results = table('Size', [num_placebo, 2], ...
    'VariableNames', {'beta', 'pValue'}, ...
    'VariableTypes', {'double', 'double'});

for perm = 1:num_placebo
    perm_LAI = standardized_LAIperi;
    for s = 1:num_sites
        perm_LAI(:, s) = standardized_LAIperi(randperm(num_years), s);
    end
    perm_model = fitlm(perm_LAI(:), Pur_vector, 'Intercept', false);
    if ~isempty(perm_model.Coefficients)
        perm_results.beta(perm) = perm_model.Coefficients.Estimate(1);
        perm_results.pValue(perm) = perm_model.Coefficients.pValue(1);
    else
        perm_results.beta(perm) = NaN;
        perm_results.pValue(perm) = NaN;
    end
end

% Clean invalid entries
perm_results = perm_results(~isnan(perm_results.beta), :);

% Empirical p-value
emp_p = sum(abs(perm_results.beta) >= abs(beta(2))) / num_placebo;
emp_p_robust = (sum(abs(perm_results.beta) >= abs(beta(2))) + 1) / (num_placebo + 1);

% Print true effect
fprintf('True effect: %.4f',beta(2));

% Visualization
figure('Units','inches','Position', [0 0 5.8 5.3]);
beta_placebo = perm_results.beta;
pval_placebo = perm_results.pValue;

% Left Y-axis: p-value scatter
yyaxis left
scatter(beta_placebo, pval_placebo, 10, ...
    'MarkerEdgeColor', [0.6353, 0.0784, 0.1843], ...
    'MarkerFaceColor', [0, 0, 0], ...
    'MarkerFaceAlpha', 0);
ylabel('{\it p-value}', 'FontWeight','bold', 'FontSize',22, 'Color', [0.6353, 0.0784, 0.1843]);
ylim([-0.05 1.1]);
set(gca,'YTick', 0:0.2:1);
set(gca, 'YColor', [0.6353, 0.0784, 0.1843]);
hold on

% Right Y-axis: Kernel density
yyaxis right
[pdf_values, xi] = ksdensity(beta_placebo, 'Bandwidth', 0.0055);
plot(xi, pdf_values, 'Color', [0, 0.4471, 0.7412], 'LineWidth', 2, 'LineStyle', '-');
ylabel('Kernel Density', 'FontWeight','bold', 'FontSize',22, 'Color',[0, 0.4471, 0.7412]);
ylim([0 50]);
set(gca, 'YColor', [0, 0.4471, 0.7412]);

% X-axis and styling
xlabel('{\it β} (Regression coefficient)', 'FontWeight','bold', 'FontSize',22, 'Color', [0,0,0]);
xlim([-0.03, 0.03]);
set(gca, 'FontName', 'Arial','FontSize', 20,'FontWeight', 'bold','LineWidth', 1.5);
set(gca, 'Box', 'on','TickDir', 'in','XGrid', 'off', 'YGrid', 'off');

% Legend
legend({'p-value', 'Kernel Density'}, ...
    'Position', [0.39 0.83 0.2 0.1], ...
    'Box', 'off', ...
    'FontName', 'Arial', ...
    'FontSize',22, ...
    'FontWeight', 'bold', ...
    'Orientation', 'horizontal');