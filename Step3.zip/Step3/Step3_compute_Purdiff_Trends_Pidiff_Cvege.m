% Based on the calculation and resampling results of the Utrack model (the python codes in floder "G:\Code\Step3\Step3_ Utrack _Model"),
% this script computes (1) Pur_diff (Fig. 3a), defined as peri-urban vegetation-induced ET and cross-boundary moisture transport contributed to the change in urban precipitation,
% (2)linear trends and significance (p‑values) of Pur_diff (Fig.3b),
% (3) Pi_diff (Fig.3c), defined as Pur_diff expressed as a percentage of each city's annual baseline precipitation,
% and (4) Cvege (Fig.3d), defined as the percentage of the Pur_diff trend to the total precipitation trend for each city (Fig.3d)
%  over 2000–2021 for 1,029 cities, and save to separate sheets in Excel.

%% Fig. 3a |  Calculation of Pur_diff
% Note: The spatial boundaries of each peri-urban area were extracted individually as shapefiles
% using ArcGIS and converted to raster masks at 0.05° resolution.
clear;clc;
% Load mapping between city index and corresponding peri-urban region ID
IDdata = xlsread("G:\Code\Step3\Step3_ID_ORIG.xlsx");

% Initialize output matrix: rows = peri-urban areas, columns = years (2000–2021)
Pur_diff = nan(1029, 22);  

% utrack moisture transport data (Python-derived, 3D: city × lat × lon)
utrack_file = "I:\ETandP\Ana\utrack\result\city_utrack_results_annual_0.05.nc";
var_name = 'annual_precipitation_source';

% Output: Excel file storing annual Pur_diff for each city
outfilename = 'G:\Code\Result_Value.xlsx';
outSheetname = 'Pur_diff';

% Get variable dimension names
var_info = ncinfo(utrack_file, var_name);
dim_names = {var_info.Dimensions.Name};  

% Process each peri-urban area
for city = 1:1029
    fprintf('Processing city-periurban pair: %d\n', city);

    % Read utrack moisture transport data for the current city
    start = [city, 1, 1];  
    count = [1, Inf, Inf];  
    utrack_slice = ncread(utrack_file, var_name, start, count);
    utrack = squeeze(utrack_slice);
    utrack = flipud(utrack);  % Flip latitudes to align with raster orientation

    % Get associated peri-urban region ID
    Periurban_id = IDdata(city, 2);

    % Read 0.05° resolution mask for the current peri-urban area
    mask_file = sprintf('I:\\ETandP\\Ana\\ETmo\\utrack\\ruralSHP\\%d.tif', Periurban_id);
    orimask = imread(mask_file);
    mask = flipud(double(orimask));  % Flip vertically to match coordinate system
    logmask = (mask == Periurban_id);  % Logical mask for pixels within peri-urban area

    % Loop over years: 2000–2021
    for ind_year = 1:22
        year = 1999 + ind_year;

        % Read ET change (ETperi_diff) for current year
        ET_file = sprintf('I:\\ETandP\\Ana\\PT_JPLim_ETmo\\result\\ETperi_diff\\nc\\ETperi_diff_%d.nc', year);
        ETperi_diff = ncread(ET_file, 'ETperi_diff');

        % Multiply ETperi_diff by transport ratio (utrack) to compute Pur_diff
        Pur_diff_grid = nan(3600, 7200);
        Pur_diff_grid(2:3600, :) = utrack(1:3599, :) .* ETperi_diff(2:3600, :);

        % Extract valid values using peri-urban mask
        valid_Pur_diff = Pur_diff_grid(logmask);
        sum_Pur_diff = nansum(valid_Pur_diff(:));  % Sum across valid pixels

        % Store result
        Pur_diff(city, ind_year) = sum_Pur_diff;
    end
end

% Write results to Excel file
output_data = [(1:1029)', nanmean(Pur_diff, 2), Pur_diff];
headers = {'ID', 'Pur_diff', '2000', '2001', '2002', '2003', '2004', '2005',...
           '2006', '2007', '2008', '2009', '2010', '2011', '2012', '2013',...
           '2014', '2015', '2016', '2017', '2018', '2019', '2020', '2021'};
xlswrite(outfilename, headers, outSheetname, 'A1'); % 写入表头
xlswrite(outfilename, output_data, outSheetname, 'A2'); % 写入数据
disp('Pur_diff computation and output completed.');

%% Fig. 3b | Pur_diff trend & significance
clear; clc;

% Input and output files
inputFile = 'G:\Code\Result_Value.xlsx';
inputSheet = 'Pur_diff';
outputFile = 'G:\Code\Result_Trend.xlsx';
outputSheet = 'Pur_diff_trend';

% Define analysis period and dimensions
years = 2000:2021;
numSites = 1029;
numYears = numel(years);
startCol = 3; % Column 3 corresponds to year 2000

% Read data table
opts = detectImportOptions(inputFile, 'Sheet', inputSheet);
opts.VariableNamesRange = 'A1:X1';   % Header row
opts.DataRange = 'A2';               % Data begins
dataTable = readtable(inputFile, opts, 'Sheet', inputSheet);

% Extract aunnual Pur_diff data (columns 2000–2021)
dataPur_diff = table2array(dataTable(:, startCol:(startCol + numYears - 1)));

% Preallocate arrays for trend and p-value results
trendsPur_diff = zeros(numSites, 1);
pValuesPur_diff = zeros(numSites, 1);

% Perform linear regression for each city
for s = 1:numSites
    y = dataPur_diff(s, :)';               % Pur_diff time series
    X = [ones(numYears, 1), years'];          % Design matrix for linear regression

    % Estimate linear trend (slope) using polyfit
    pFit = polyfit(years, y', 1);
    trendsPur_diff(s) = pFit(1);

    % Estimate significance (p-value) using ordinary least squares
    [~, ~, ~, ~, stats] = regress(y, X);
    pValuesPur_diff(s) = stats(3);              % Extract p-value
end

% Create output table including IDs
outputTable = table( ...
    dataTable.ID, ...
    trendsPur_diff, ...
    pValuesPur_diff, ...
    'VariableNames', {'SiteID', 'Trend_Pur_diff', 'PValue_Pur_diff'});

writetable(outputTable, outputFile, 'Sheet', outputSheet, 'WriteMode', 'overwritesheet');
fprintf('Pur_diff trends saved to %s (sheet: %s)\n', outputFile, outputSheet);


%% Fig. 3c |  Calculation of Pi_diff
clear; clc
% Input and output settings
inputFile = 'G:\Code\Result_Value.xlsx';
Pur_Sheet = 'Pur';          % Annual precipitation
Pur_diff_Sheet = 'Pur_diff'; % Annual Pur_diff
outputFile =  'G:\Code\Result_Value.xlsx';
outputSheet = 'Pi_diff'; % Output sheet name

% Define analysis period and dimensions
years = 2000:2021;
numSites = 1029;
numYears = numel(years);
startCol = 2;  % Column 2 corresponds to the average of 2000-2021, and column 3 corresponds to year 2000

% Read Pur data
optsPur = detectImportOptions(inputFile, 'Sheet', Pur_Sheet);
optsPur.VariableNamesRange = 'A1:X1';  
optsPur.DataRange = 'A2';              
dataTablePur = readtable(inputFile, optsPur, 'Sheet', Pur_Sheet);
dataPur = table2array(dataTablePur(:, startCol:(startCol + numYears)));

% Read Pur_diff data
optsPur_diff = detectImportOptions(inputFile, 'Sheet', Pur_diff_Sheet);
optsPur_diff.VariableNamesRange = 'A1:X1';  
optsPur_diff.DataRange = 'A2';              
dataTablePur_diff = readtable(inputFile, optsPur_diff, 'Sheet', Pur_diff_Sheet);
dataPur_diff = table2array(dataTablePur_diff(:, startCol:(startCol + numYears)));

% Calculate Pi_diff
Pi_diff = abs(dataPur_diff ./ dataPur);

% Create output table headers
outputData = [dataTablePur.ID, Pi_diff];
yearHeaders = strcat(string(years)); 
outputTable = array2table(outputData, ...
    'VariableNames', ['ID'; 'Pi_diff'; yearHeaders']);

writetable(outputTable, outputFile, 'Sheet', outputSheet, 'WriteMode', 'overwritesheet');
fprintf('Pi_diff saved to %s (sheet: %s)\n', outputFile, outputSheet);

%% Fig. 3d |  Calculation of Cvege
clear; clc
% Input and output settings
inputFile = 'G:\Code\Result_Trend.xlsx';
Pur_trend_Sheet = 'Pur_trend';          % Trend of total precipitation
Pur_diff_trend_Sheet = 'Pur_diff_trend'; % Trend of Pur_diff (change attributed to ETperi_diff)
outputFile =  'G:\Code\Result_Value.xlsx';
outputSheet = 'Cvege'; % Output sheet name

% Define analysis period and dimensions
numSites = 1029;
startCol = 2;  % Column 2 corresponds to the average of 2000-2021, and column 3 corresponds to year 2000

% Read Pur_trend data
optsPur_trend = detectImportOptions(inputFile, 'Sheet', Pur_trend_Sheet);
optsPur_trend.VariableNamesRange = 'A1:C1';  
optsPur_trend.DataRange = 'A2';              
dataTablePur_trend = readtable(inputFile, optsPur_trend, 'Sheet', Pur_trend_Sheet);
dataPur_trend = table2array(dataTablePur_trend(:, 2));

% Read Pur_diff_trend data
optsPur_diff_trend = detectImportOptions(inputFile, 'Sheet', Pur_diff_trend_Sheet);
optsPur_diff_trend.VariableNamesRange = 'A1:C1';  
optsPur_diff_trend.DataRange = 'A2';              
dataTablePur_diff_trend = readtable(inputFile, optsPur_diff_trend, 'Sheet', Pur_diff_trend_Sheet);
dataPur_diff_trend = table2array(dataTablePur_diff_trend(:,2));

% Calculate Cvege
Cvege = dataPur_diff_trend ./ dataPur_trend;

% Create output table headers
outputData = [dataTablePur_trend.SiteID, Cvege];
outputTable = array2table(outputData, ...
    'VariableNames', {'ID'; 'Cvege'});

writetable(outputTable, outputFile, 'Sheet', outputSheet, 'WriteMode', 'overwritesheet');
fprintf('Cvege saved to %s (sheet: %s)\n', outputFile, outputSheet);
