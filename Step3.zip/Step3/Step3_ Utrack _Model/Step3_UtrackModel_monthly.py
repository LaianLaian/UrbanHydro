# This script processes moisture source contributions for multiple cities using utrack monthly climatology data.
# For each city, it calculates the surrounding source contribution of precipitation by reading 12 monthly NetCDF files.
# The analysis focuses on a spatial window (11x11 grid cells) around each city to capture local source regions.

import numpy as np
import pandas as pd
from netCDF4 import Dataset
import os
import gc

def create_mask(lon_idx, lat_idx, shape, buffer_size=5):
    """
    Create a binary mask that preserves a square region (buffer_size*2+1) centered at a given (lon_idx, lat_idx).
    This function handles longitudinal wrapping for global gridded data.

    Parameters:
        lon_idx (int): Longitude index of the target grid point.
        lat_idx (int): Latitude index of the target grid point.
        shape (tuple): Shape of the 2D grid (lon_size, lat_size).
        buffer_size (int): Number of grid cells to extend in each direction (default is 5, i.e., 11x11 window).

    Returns:
        mask (np.ndarray): Boolean mask of the same shape as the grid, with True in the preserved region.
    """
    mask = np.zeros(shape, dtype=bool)

    # Iterate over window centered on the city grid point
    for i in range(-5, 6):  # Longitude window
        for j in range(-5, 6):  # Latitude window
            current_lon = (lon_idx + i) % shape[0]  # Handle longitudinal wrapping
            current_lat = lat_idx + j
            if 0 <= current_lat < shape[1]:
                mask[current_lon, current_lat] = True
    return mask

def process_city_data():
    """
    Main function to calculate and save monthly precipitation source contributions (from utrack)
    for all cities listed in the input Excel file. Data is processed in batches to optimize memory usage.
    """
    print("Reading city coordinates...")
    df = pd.read_excel('city_latlon.xlsx')
    print("City columns:", list(df.columns))
    print()

    n_cities = len(df)
    batch_size = 50  # Process cities in batches

    # Create output NetCDF file
    with Dataset('city_utrack_results_monthly.nc', 'w') as nc:
        # Define dimensions
        nc.createDimension('city', n_cities)
        nc.createDimension('lon', 720)
        nc.createDimension('lat', 360)
        nc.createDimension('time', 12)

        # Define variables
        city_id = nc.createVariable('city_id', 'i4', ('city',))
        city_lat = nc.createVariable('city_lat', 'f4', ('city',))
        city_lon = nc.createVariable('city_lon', 'f4', ('city',))
        lon = nc.createVariable('lon', 'f4', ('lon',))
        lat = nc.createVariable('lat', 'f4', ('lat',))
        time = nc.createVariable('time', 'i4', ('time',))
        data = nc.createVariable('precipitation_source', 'f4', ('lon', 'lat', 'city', 'time'),
                                 chunksizes=(720, 360, 1, 1), fill_value=np.nan)

        # Add metadata to variables
        city_id.long_name = 'City ID'
        city_lat.long_name = 'City Latitude'
        city_lat.units = 'degrees_north'
        city_lon.long_name = 'City Longitude'
        city_lon.units = 'degrees_east'
        lon.long_name = 'Longitude'
        lon.units = 'degrees_east'
        lat.long_name = 'Latitude'
        lat.units = 'degrees_north'
        time.long_name = 'Month'
        time.units = 'month'
        data.long_name = 'Monthly Precipitation Source Contribution'
        data.units = 'percent'

        # Write city and coordinate data
        city_id[:] = df['ID'].values
        city_lat[:] = df['lat'].values

        # Convert longitudes from -180~180 to 0~360
        city_lon_values = df['lon'].values.copy()
        city_lon_values[city_lon_values < 0] += 360
        city_lon[:] = city_lon_values

        lon[:] = np.arange(0, 360, 0.5)
        lat[:] = np.arange(90, -90, -0.5)
        time[:] = np.arange(1, 13)

        # Process cities in batches
        for batch_start in range(0, n_cities, batch_size):
            batch_end = min(batch_start + batch_size, n_cities)
            print(f"\nProcessing city batch {batch_start + 1} to {batch_end}...")

            batch_data = np.full((720, 360, batch_end - batch_start, 12), np.nan, dtype=np.float32)

            for city_idx in range(batch_start, batch_end):
                rel_idx = city_idx - batch_start
                print(f"\nProcessing city {city_idx + 1}/{n_cities}...")

                city_id_val = df['ID'].iloc[city_idx]
                city_lat_val = df['lat'].iloc[city_idx]
                city_lon_val = df['lon'].iloc[city_idx]
                print(f"City ID: {city_id_val}")

                # Convert to 0–360 if necessary
                if city_lon_val < 0:
                    city_lon_val += 360

                # Convert lat/lon to raster grid indices
                target_lat_idx = int(round(180 - city_lat_val/0.5 + 1)) - 1
                target_lon_idx = int(round(city_lon_val/0.5 + 1)) - 1

                # Clamp to valid index range
                target_lat_idx = max(0, min(359, target_lat_idx))
                target_lon_idx = max(0, min(719, target_lon_idx))

                # Create spatial mask (11x11 window)
                mask = create_mask(target_lon_idx, target_lat_idx, (720, 360))

                for month in range(1, 13):
                    print(f"Processing month {month}...")
                    filename = f'utrack_climatology_0.5_{month:02d}.nc'

                    try:
                        print(f"Reading data from file {filename}...")
                        with Dataset(filename, 'r') as nc_in:
                            # Extract moisture flow for given city grid point
                            MOI = nc_in.variables['moisture_flow'][:, :, target_lat_idx, target_lon_idx]
                            MOI = np.array(MOI, dtype=np.float32)

                            # Compute source contribution using exponential decay function (Eq. 5)
                            source_contribution = np.exp(MOI * -0.1)

                            # Replace invalid values with 0
                            source_contribution = np.nan_to_num(source_contribution, 0)

                            # Skip if no contribution exists
                            if np.all(source_contribution == 0):
                                print(f"Warning: All contribution values are 0 for city {city_id_val}, month {month}")
                                continue

                            # Normalize to percentage (Eq. 6)
                            total = np.sum(source_contribution)
                            if total > 0:
                                source_contribution = source_contribution / total * 100

                            # Transpose to (lon, lat) format
                            source_contribution = source_contribution.T

                            # Log statistics over entire field
                            print(f"Full domain - Range: [{source_contribution.min():.2f}, {source_contribution.max():.2f}], "
                                  f"Mean: {source_contribution.mean():.2f}, "
                                  f"Sum: {np.sum(source_contribution):.2f}%")

                            # Store result in batch_data array
                            batch_data[:, :, rel_idx, month-1] = source_contribution

                            # Mask values outside of 11x11 window
                            batch_data[:, :, rel_idx, month-1] = np.where(mask, batch_data[:, :, rel_idx, month-1], np.nan)

                            # Log statistics over masked region
                            valid_data = batch_data[:, :, rel_idx, month-1][~np.isnan(batch_data[:, :, rel_idx, month-1])]
                            print(f"Masked region - Range: [{np.min(valid_data):.2f}, {np.max(valid_data):.2f}], "
                                  f"Mean: {np.mean(valid_data):.2f}, "
                                  f"Sum: {np.sum(valid_data):.2f}%, "
                                  f"Grid count: {len(valid_data)}")

                    except Exception as e:
                        print(f"Error reading file {filename}: {str(e)}")
                        continue

                # Free memory after each city
                gc.collect()

            # Write current batch to NetCDF file
            print(f"\nSaving batch {batch_start + 1} to {batch_end}...")
            data[:, :, batch_start:batch_end, :] = batch_data
            del batch_data
            gc.collect()

    print("\nAll processing complete!")

if __name__ == '__main__':
    process_city_data()
