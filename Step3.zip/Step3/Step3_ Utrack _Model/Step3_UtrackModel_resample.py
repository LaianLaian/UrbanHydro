# This script resamples UTrack model results from 0.5° to 0.05° resolution for each city.
# For each city and time step (monthly or annual), the script:
#   1. Extracts valid precipitation source regions,
#   2. Applies bilinear interpolation,
#   3. Performs both local and global normalization to conserve total moisture contribution.

import numpy as np
from netCDF4 import Dataset
import xarray as xr
from scipy.interpolate import griddata
from scipy.ndimage import map_coordinates
import time
import os


def adjust_longitude(lon):
    """
    Adjust longitudes from -180–180 to 0–360 if necessary.

    Args:
        lon: array of longitudes

    Returns:
        Adjusted longitude array in 0–360 range
    """
    if np.any(lon < 0):
        lon = np.where(lon < 0, lon + 360, lon)
    return lon


def resample_and_normalize(input_file, output_dir, scale_factor=10, start_city_idx=0):
    """
    Resample 0.5° UTrack data to 0.05°, ensuring total precipitation source is conserved.
    Generates one output file per city.

    Args:
        input_file: Path to the original UTrack NetCDF file
        output_dir: Directory to save per-city output files
        scale_factor: Resampling ratio (default: 10 for 0.5°→0.05°)
        start_city_idx: Index to start processing from (default: 0)
    """
    print(f"Starting to process file: {input_file}")
    start_time = time.time()

    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
        print(f"Created output directory: {output_dir}")

    try:
        with Dataset(input_file, 'r') as nc_in:
            print("Reading input NetCDF file...")
            data = nc_in.variables['precipitation_source'][:] if 'precipitation_source' in nc_in.variables else \
            nc_in.variables['annual_precipitation_source'][:]
            lon = nc_in.variables['lon'][:]
            lat = nc_in.variables['lat'][:]
            city_id = nc_in.variables['city_id'][:]
            city_lat = nc_in.variables['city_lat'][:]
            city_lon = nc_in.variables['city_lon'][:]

            print("Checking longitude range...")
            original_lon_range = f"{lon[0]} to {lon[-1]}"
            lon = adjust_longitude(lon)
            city_lon = adjust_longitude(city_lon)
            print(f"Longitude adjusted from {original_lon_range} to {lon[0]} to {lon[-1]}")

            n_lon = len(lon)
            n_lat = len(lat)
            n_cities = len(city_id)
            n_time = data.shape[3] if len(data.shape) == 4 else 1

            print(f"Data dimensions: lon={n_lon}, lat={n_lat}, cities={n_cities}, time steps={n_time}")
            print(f"Starting from city index: {start_city_idx + 1}")

            print("Creating new longitude and latitude grids...")
            new_lon = np.linspace(lon[0], lon[-1], n_lon * scale_factor)
            new_lat = np.linspace(lat[0], lat[-1], n_lat * scale_factor)

            lon_grid, lat_grid = np.meshgrid(lon, lat, indexing='ij')
            new_lon_grid, new_lat_grid = np.meshgrid(new_lon, new_lat, indexing='ij')

            print("Beginning per-city processing...")
            for city_idx in range(start_city_idx, n_cities):
                city_start_time = time.time()
                current_city_id = city_id[city_idx]
                current_city_lat = city_lat[city_idx]
                current_city_lon = city_lon[city_idx]

                print(f"\nProcessing city {city_idx + 1}/{n_cities} (ID: {current_city_id})")
                print(f"City location: lon={current_city_lon:.2f}, lat={current_city_lat:.2f}")

                output_file = os.path.join(output_dir,
                                           f'city_{current_city_id}_lat{current_city_lat:.2f}_lon{current_city_lon:.2f}.nc')

                if os.path.exists(output_file):
                    try:
                        os.remove(output_file)
                        print(f"Deleted existing output file: {output_file}")
                    except PermissionError:
                        print(f"Error: Cannot delete existing output file {output_file}. Check permissions.")
                        continue

                try:
                    with Dataset(output_file, 'w') as nc_out:
                        nc_out.createDimension('lon', len(new_lon))
                        nc_out.createDimension('lat', len(new_lat))
                        if n_time > 1:
                            nc_out.createDimension('time', n_time)

                        print("Creating output variables...")
                        lon_out = nc_out.createVariable('lon', 'f4', ('lon',))
                        lat_out = nc_out.createVariable('lat', 'f4', ('lat',))
                        if n_time > 1:
                            time_out = nc_out.createVariable('time', 'i4', ('time',))
                            data_out = nc_out.createVariable('precipitation_source', 'f4', ('lon', 'lat', 'time'),
                                                             chunksizes=(len(new_lon), len(new_lat), 1),
                                                             fill_value=np.nan)
                        else:
                            data_out = nc_out.createVariable('annual_precipitation_source', 'f4', ('lon', 'lat'),
                                                             chunksizes=(len(new_lon), len(new_lat)), fill_value=np.nan)

                        print("Copying variable attributes...")
                        for var in nc_in.variables:
                            if var in nc_out.variables:
                                for attr in nc_in.variables[var].ncattrs():
                                    if attr != '_FillValue':
                                        nc_out.variables[var].setncattr(attr, nc_in.variables[var].getncattr(attr))

                        print("Writing metadata and coordinate data...")
                        lon_out[:] = new_lon
                        lat_out[:] = new_lat
                        if n_time > 1:
                            time_out[:] = nc_in.variables['time'][:]

                        nc_out.city_id = current_city_id
                        nc_out.city_lat = current_city_lat
                        nc_out.city_lon = current_city_lon
