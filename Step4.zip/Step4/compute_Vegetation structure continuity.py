# In order to conduct the analysis of Vegetation structure continuity,
# this script computes the vegetation fragmentation index (Structural Integrity Index, SI)
# for peri-urban regions based on LAI spatial patterns.
# The 75th percentile of LAI is used as a threshold to define "vegetated" pixels.
# Connected vegetated patches are extracted, and their areas are used to calculate
# SI, patch count, and total green area per city.

import os
import numpy as np
import pandas as pd
import rasterio
from skimage.measure import label, regionprops
import logging

# Configure logging to monitor progress and potential issues
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')


def calculate_fragmentation_lai(tif_path, min_patch_area=1):
    """
    Calculate vegetation fragmentation index (Structural Integrity Index, SI)
    from an LAI raster by identifying vegetated patches above the 75th percentile.

    Parameters:
        tif_path (str): Path to input LAI raster file.
        min_patch_area (int): Minimum pixel count to consider a patch valid.

    Returns:
        SI (float): Shannon Index indicating vegetation fragmentation.
        num_patches (int): Total number of valid green patches.
        total_green_area (int): Sum of all vegetated patch areas (in pixels).
        lai_p75 (float): 75th percentile LAI threshold used for binary classification.
    """
    try:
        # Read raster data
        with rasterio.open(tif_path) as src:
            data = src.read(1)

        # Create binary mask of valid data
        valid_mask = ~np.isnan(data)

        # Define vegetated threshold (75th percentile of LAI values)
        lai_p75 = np.nanpercentile(data, 75)
        binary = (data > lai_p75) & valid_mask

        # Label connected components (patches)
        labeled = label(binary, connectivity=2)
        regions = [r for r in regionprops(labeled) if r.area >= min_patch_area]

        # Extract patch areas
        patch_areas = np.array([r.area for r in regions])
        total_green_area = patch_areas.sum()

        # Compute Shannon Index (SI)
        if total_green_area > 0:
            SI = 1 - np.sum((patch_areas / total_green_area) ** 2)
        else:
            SI = 0

        return SI, len(regions), total_green_area, lai_p75
    except Exception as e:
        print(f"Error calculating fragmentation index: {str(e)}")
        return None, None, None, None


def main():
    """
    Main function to process all city-level peri-urban LAI raster files and
    calculate fragmentation metrics.

    Results are saved to an Excel file: 'lai_fragmentation_SI.xlsx'
    """
    # Directory containing input TIFF files
    input_dir = 'city_tifs'
    output_file = 'lai_fragmentation_SI.xlsx'

    # List all TIFF files
    tif_files = [f for f in os.listdir(input_dir) if f.endswith('.tif')]
    logging.info(f"Found {len(tif_files)} TIFF files for analysis.")

    results = []

    # Loop through each city file
    for tif_file in tif_files:
        city_id = tif_file.split('_')[1].split('.')[0]

        # Compute fragmentation metrics
        SI, num_patches, total_green_area, lai_p75 = calculate_fragmentation_lai(
            os.path.join(input_dir, tif_file)
        )

        if SI is not None:
            results.append({
                'city_id': city_id,
                'fragmentation_SI': SI,
                'num_patches': num_patches,
                'total_green_area': total_green_area,
                'lai_p75': lai_p75
            })
            print(f"{city_id}: SI={SI:.4f}, patches={num_patches}, area={total_green_area}, lai_p75={lai_p75:.4f}")

    # Export results to Excel
    if results:
        df = pd.DataFrame(results)[['city_id', 'fragmentation_SI', 'num_patches', 'total_green_area', 'lai_p75']]
        df.to_excel(output_file, index=False)
        print(f"Fragmentation metrics saved to {output_file}")


if __name__ == "__main__":
    main()
