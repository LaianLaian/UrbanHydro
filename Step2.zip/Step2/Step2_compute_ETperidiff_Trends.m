% Based on the calculation results of the PT-JPLim model (the MATLAB codes in "G:\Code\Step2\Step2_PTJPLim_Model" folder),
% this script computes annual vegetation-induced peri-urban evapotranspiration change (ETperi_diff)
% under both real- and fixed- vegetation change
% scenarios for the period 2000–2021 with the converts of results to 0.05° spatial resolution (Fig. 2a).
%
% And this script also computes the linear trends and statistical significance (p-values) 
% of ETperi_diff over 2000–2021 for 1,029 peri-urban areas (Fig. 2b). and writes results to Excel files.

%% Fig. 2a | Compute annual ETperi_diff using PT-JPLim model (2000–2021)
clear; clc;

% Initialize resolution settings
high_res = nan(3600, 7200);
longitude = double(0:0.05:359.95);
latitude = double(-90:0.05:89.95);

for year = 2000:2021
    ind_year = year - 1999;
    fprintf('Processing %d...\n', year);

    % Read original model output (ET difference between changed vs unchanged vegetation)
    input_filename = sprintf('I:\\ETandP\\Ana\\PT_JPLim_ETmo\\result\\ETperi_diff\\nc\\ETperi_diff_%d.nc', year);
    original_ETperi_diff = ncread(input_filename, 'ETperi_diff');

    % Spatial resolution conversion to 0.05°
    high_res = original_ETperi_diff(ceil((1:3600)/2), ceil((1:7200)/2));

    % Write high-resolution ETperi_diff into a new NetCDF file
    output_filename = sprintf('I:\\ETandP\\Ana\\PT_JPLim_ETmo\\result\\ETperi_diff\\nc005\\ETperi_diff_%d.nc', year);
    ncid = netcdf.create(output_filename, 'CLOBBER');

    % Define dimensions
    dimid_lon = netcdf.defDim(ncid, 'lon', 7200);
    dimid_lat = netcdf.defDim(ncid, 'lat', 3600);

    % Define variables
    varid_lon = netcdf.defVar(ncid, 'lon', 'double', dimid_lon);
    varid_lat = netcdf.defVar(ncid, 'lat', 'double', dimid_lat);
    varid_data = netcdf.defVar(ncid, 'ETperi_diff', 'double', [dimid_lat, dimid_lon]);

    % Add metadata
    netcdf.putAtt(ncid, varid_lon, 'long_name', 'Longitude');
    netcdf.putAtt(ncid, varid_lon, 'units', 'degrees_east');
    netcdf.putAtt(ncid, varid_lat, 'long_name', 'Latitude');
    netcdf.putAtt(ncid, varid_lat, 'units', 'degrees_north');
    netcdf.putAtt(ncid, varid_data, 'long_name', 'ETperi_diff');
    netcdf.putAtt(ncid, varid_data, 'units', 'mm/yr');
    netcdf.putAtt(ncid, varid_data, 'missing_value', single(32766));

    netcdf.endDef(ncid);  % Exit define mode

    % Write variables
    netcdf.putVar(ncid, varid_lon, longitude);
    netcdf.putVar(ncid, varid_lat, latitude);
    netcdf.putVar(ncid, varid_data, high_res);
    netcdf.close(ncid);
end

disp('--- Completed spatial resolution conversion for annual ETperi_diff ---');

% NOTE:
% The resulting high-resolution ETperi_diff NetCDF files were imported into ArcGIS.
% Using the Zonal Statistics as Table tool, annual mean ETperi_diff values for each peri-urban zone (2000–2021)
% were extracted and recorded in the "ETperi_diff" sheet of: 
% G:\Code\Result_Value.xlsx
% (The result files are stored in the folder G:\Code\Step2\Step2_Results_ETperi_diff)

%% Fig. 2b | Vegetation-induced peri‑urban evapotranspiration change (ETperi_diff) trend & significance
clear; clc;

% Input and output files
inputFile = 'G:\Code\Result_Value.xlsx';
inputSheet = 'ETperi_diff';
outputFile = 'G:\Code\Result_Trend.xlsx';
outputSheet = 'ETperi_diff_trend';

% Define analysis period and dimensions
years = 2000:2021;
numSites = 1029;
numYears = numel(years);
startCol = 3; % Column 3 corresponds to year 2000

% Read data table
opts = detectImportOptions(inputFile, 'Sheet', inputSheet);
opts.VariableNamesRange = 'A1:X1';   % Header row
opts.DataRange = 'A2';               % Data begins
dataTable = readtable(inputFile, opts, 'Sheet', inputSheet);

% Extract aunnual ETperi_diff data (columns 2000–2021)
dataETperi_diff = table2array(dataTable(:, startCol:(startCol + numYears - 1)));

% Preallocate arrays for trend and p-value results
trendsETperi_diff = zeros(numSites, 1);
pValuesETperi_diff = zeros(numSites, 1);

% Perform linear regression for each peri-urban area
for s = 1:numSites
    y = dataETperi_diff(s, :)';               % ETperi_diff time series
    X = [ones(numYears, 1), years'];          % Design matrix for linear regression

    % Estimate linear trend (slope) using polyfit
    pFit = polyfit(years, y', 1);
    trendsETperi_diff(s) = pFit(1);

    % Estimate significance (p-value) using ordinary least squares
    [~, ~, ~, ~, stats] = regress(y, X);
    pValuesETperi_diff(s) = stats(3);              % Extract p-value
end

% Create output table including IDs
outputTable = table( ...
    dataTable.ID, ...
    trendsETperi_diff, ...
    pValuesETperi_diff, ...
    'VariableNames', {'SiteID', 'Trend_ETperi_diff', 'PValue_ETperi_diff'});

writetable(outputTable, outputFile, 'Sheet', outputSheet, 'WriteMode', 'overwritesheet');
fprintf('ETperi_diff trends saved to %s (sheet: %s)\n', outputFile, outputSheet);