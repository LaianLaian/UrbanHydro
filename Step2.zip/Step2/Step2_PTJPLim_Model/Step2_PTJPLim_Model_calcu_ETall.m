% Performance optimized version 0312 for PTJPLim ET calculation
clear
clc
longitude = 0:0.1:359.9;
latitude = -90:0.1:89.9;  % Modified to south-to-north order

% Start timing for performance monitoring
total_start_time = tic;
fprintf('\n========== Starting Total ET Calculation Program ==========\n');
fprintf('Start time: %s\n', datestr(now, 'yyyy-mm-dd HH:MM:SS'));

% Define data reading parameters for NetCDF files
abc = (2000-1981)*12-11;
start1 = [1 1 abc]; 
count1 = [3600 1800 264]; 
start = [abc 1 1]; 
count = [264 1800 3600]; 

% Check latitude order of input data
fprintf('Checking latitude order of input data...\n');

% Function: Attempt to read latitude data from various variable names
function lat = try_read_latitude(filename)
    try
        lat = ncread(filename, 'latitude');
    catch
        try
            lat = ncread(filename, 'lat');
        catch
            try
                lat = ncread(filename, 'LAT');
            catch
                fprintf('Warning: Unable to read latitude information from %s\n', filename);
                lat = [];
            end
        end
    end
end

% Read latitude information from input files and check orientation
fprintf('Checking latitude direction of data files...\n');

% Check soil moisture data
soil_lat = try_read_latitude('soilwater12023.nc');
if ~isempty(soil_lat)
    fprintf('Soil moisture data latitude range: %.1f to %.1f\n', min(soil_lat), max(soil_lat));
end

% Set flip flag based on latitude orientation
need_flip = false;
if ~isempty(soil_lat)
    if soil_lat(1) < soil_lat(end)  % If latitude is south-to-north (-90 to 90)
        need_flip = false;
        fprintf('Detected input data latitude order as south-to-north, conforming to standard\n');
    else
        need_flip = true;
        fprintf('Detected input data latitude order as north-to-south, need to flip to south-to-north\n');
    end
else
    fprintf('Warning: Unable to detect latitude direction, using default south-to-north order\n');
end

% Pre-allocate large arrays for memory efficiency
fprintf('Pre-allocating memory...\n');
SM = zeros(264,1800,3600,'single');
ETc = zeros(264,1800,3600,'single');
ETs = zeros(264,1800,3600,'single');
ETall = zeros(264,1800,3600,'single');
ETyr = zeros(22,1800,3600,'single');

%%  -------Start to calculate ETs-------
fprintf('========== Step 1: Reading Soil Moisture Data ==========\n');
step_time = tic;

% Direct reading and processing of data
fprintf('Starting block-wise reading of soil moisture data...\n');
block_size = 50;  % Process 50 time steps at a time
n_blocks = ceil(264/block_size);

for b = 1:n_blocks
    block_time = tic;
    fprintf('Processing soil moisture data block: %d/%d\n', b, n_blocks);
    
    % Calculate current block range
    start_idx = (b-1)*block_size + abc;
    count_size = min(block_size, 264 - (b-1)*block_size);
    
    % Set reading range
    start_block = [1 1 start_idx];
    count_block = [3600 1800 count_size];
    
    % Read current block data
    SM1_block = ncread('soilwater12023.nc', 'swvl1', start_block, count_block);
    SM2_block = ncread('soilwater22023.nc', 'swvl2', start_block, count_block);
    SM3_block = ncread('soilwater32023.nc', 'swvl3', start_block, count_block);
    
    % Vectorized processing
    SM1_block(SM1_block > 1) = 1;
    SM2_block(SM2_block > 1) = 1;
    SM3_block(SM3_block > 1) = 1;
    
    % Calculate weighted average
    SM_block = 0.07*SM1_block + 0.21*SM2_block + 0.72*SM3_block;
    clear SM1_block SM2_block SM3_block
    
    % Adjust dimension order and store results
    idx_start = (b-1)*block_size + 1;
    idx_end = idx_start + count_size - 1;
    SM(idx_start:idx_end,:,:) = permute(SM_block, [3 2 1]);
    clear SM_block
    
    fprintf('Data block %d processing completed in %.2f seconds\n', b, toc(block_time));
end

% Add flip processing after reading data
if need_flip
    fprintf('Flipping data to maintain consistent latitude direction (south-to-north)...\n');
    SM = flip(SM, 2);  % Flip latitude dimension
end
SM(SM(:,:,:)<0)=0;
clear soil_lat  % Clear soil moisture related temporary variables

fprintf('Soil moisture data processing completed in %.2f seconds\n\n', toc(step_time));

% Generate spatial distribution plot for SM after calculation
fprintf('Generating spatial distribution plot for SM...\n');
SM_mean = squeeze(mean(SM, 1));  % Calculate temporal mean
figure('Position', [100 100 800 600]);
imagesc(longitude, latitude, SM_mean);
colormap(jet(256));
colorbar;
title('Spatial Distribution of Soil Moisture (SM)');
xlabel('Longitude');
ylabel('Latitude');
set(gcf, 'Color', 'white');
print('H:\ServerERA\ET2024_Simulation\SM_distribution.png', '-dpng', '-r300');
clear SM_mean

fprintf('========== Step 2: Processing Root Depth Data ==========\n');
step_time = tic;
% Read data
zr0 = ncread('CH2025.nc', 'CH');

% Initialize CH array and assign values
CH = zeros(1,1800,3600,'single');
CH(1,:,:) = zr0;
clear zr0  % Clear temporary variables

% Calculate CHsc (scaled root depth)
CHsc = (CH).^0.5;
CHsc(CHsc < 1) = 1;
CHsc(CHsc > 5) = 5;

% Generate spatial distribution plot for CH after calculation
fprintf('Generating spatial distribution plot for CH...\n');
CH_plot = squeeze(CH(1,:,:));
figure('Position', [100 100 800 600]);
imagesc(longitude, latitude, CH_plot);
colormap(jet(256));
colorbar;
title('Spatial Distribution of Root Depth (CH)');
xlabel('Longitude');
ylabel('Latitude');
set(gcf, 'Color', 'white');
print('H:\ServerERA\ET2024_Simulation\CH_distribution.png', '-dpng', '-r300');
clear CH_plot

fprintf('Root depth data processing completed in %.2f seconds\n\n', toc(step_time));

fprintf('========== Step 3: Calculating Wilting Point ==========\n');
step_time = tic;
% Read wilting point data
diaowei0 = ncread('Wilting_point_processed.nc','Wilting_point');
    
% Calculate adjusted wilting point
diaoweich = diaowei0./CHsc;

% Generate spatial distribution plot for diaoweich after calculation
fprintf('Generating spatial distribution plot for adjusted wilting point...\n');
diaoweich_plot = squeeze(diaoweich(1,:,:));
figure('Position', [100 100 800 600]);
imagesc(longitude, latitude, diaoweich_plot);
colormap(jet(256));
colorbar;
title('Spatial Distribution of Adjusted Wilting Point');
xlabel('Longitude');
ylabel('Latitude');
set(gcf, 'Color', 'white');
print('H:\ServerERA\ET2024_Simulation\diaoweich_distribution.png', '-dpng', '-r300');
clear diaoweich_plot

fprintf('Wilting point calculation completed in %.2f seconds\n\n', toc(step_time));

fprintf('========== Step 4: Calculating p and xitacr Parameters ==========\n');
step_time = tic;

% Direct reading of PET data
fprintf('Reading PET data...\n');
PET = ncread('H:\ServerERA\ET2024_Simulation\PET2025.nc', 'PET');
% Generate spatial distribution plot for PET
fprintf('Generating spatial distribution plot for PET...\n');
p_mean = squeeze(mean(PET, 1));
figure('Position', [100 100 800 600]);
imagesc(longitude, latitude, p_mean);
colormap(jet(256));
colorbar;
title('Spatial Distribution of PET');
xlabel('Longitude');
ylabel('Latitude');
set(gcf, 'Color', 'white');
print('H:\ServerERA\ET2024_Simulation\PET_distribution.png', '-dpng', '-r300');
clear p_mean
% Calculate p
fprintf('Calculating p...\n');
p = (1./(1+PET)) - (0.1./(CH+1));

% Generate spatial distribution plot for p after calculation
fprintf('Generating spatial distribution plot for p...\n');
p_mean = squeeze(mean(p, 1));
figure('Position', [100 100 800 600]);
imagesc(longitude, latitude, p_mean);
colormap(jet(256));
colorbar;
title('Spatial Distribution of p');
xlabel('Longitude');
ylabel('Latitude');
set(gcf, 'Color', 'white');
print('H:\ServerERA\ET2024_Simulation\p_distribution.png', '-dpng', '-r300');
clear p_mean
p(p(:,:,:)<0)=0;
p(p(:,:,:)>1)=1;
clear PET
% Calculate xitacr in blocks
fprintf('Starting block-wise calculation of xitacr...\n');
block_size = 600;  % Process 600 longitude points at a time
n_blocks = ceil(3600/block_size);
xitacr = zeros(264,1800,3600,'single');  % Pre-allocate memory

% First calculate Field0
fprintf('Calculating Field0...\n');
Field0 = zeros(1,1800,3600,'single');
for b = 1:n_blocks
    block_time = tic;
    fprintf('Processing Field0 data block: %d/%d\n', b, n_blocks);
    
    % Calculate current block range
    start_idx = (b-1)*block_size + 1;
    end_idx = min(b*block_size, 3600);
    curr_slice = start_idx:end_idx;
    
    % Calculate current block's Field0
    Field0_block = max(SM(:,:,curr_slice),[],1);
    % Set minimum value to 0.3 to ensure globally reasonable distribution values
    % This prevents unrealistically low field capacity values in arid regions
    Field0_block(Field0_block(1,:,:)<0.3)=0.3;
    Field0(1,:,curr_slice) = Field0_block;
    
    clear Field0_block
    fprintf('Field0 data block %d processing completed in %.2f seconds\n', b, toc(block_time));
end

% Generate spatial distribution plot for Field0 after calculation
fprintf('Generating spatial distribution plot for Field0...\n');
Field0_plot = squeeze(Field0(1,:,:));
figure('Position', [100 100 800 600]);
imagesc(longitude, latitude, Field0_plot);
colormap(jet(256));
colorbar;
title('Spatial Distribution of Field0');
xlabel('Longitude');
ylabel('Latitude');
set(gcf, 'Color', 'white');
print('H:\ServerERA\ET2024_Simulation\Field0_distribution.png', '-dpng', '-r300');
clear Field0_plot

% Calculate xitacr in blocks
for b = 1:n_blocks
    block_time = tic;
    fprintf('Processing xitacr data block: %d/%d\n', b, n_blocks);
    
    % Calculate current block range
    start_idx = (b-1)*block_size + 1;
    end_idx = min(b*block_size, 3600);
    curr_slice = start_idx:end_idx;
    
    % Extract current block data
    p_block = p(:,:,curr_slice);
    Field0_block = Field0(:,:,curr_slice);
    diaoweich_block = diaoweich(:,:,curr_slice);
    
    % Calculate current block's xitacr
    xitacr(:,:,curr_slice) = (1-p_block).*(Field0_block-diaoweich_block) + diaoweich_block;
    
    % Clear temporary variables
    clear p_block Field0_block diaoweich_block
    fprintf('xitacr data block %d processing completed in %.2f seconds\n', b, toc(block_time));
end

% Generate spatial distribution plot for xitacr after calculation
fprintf('Generating spatial distribution plot for xitacr...\n');
xitacr_mean = squeeze(mean(xitacr, 1));
figure('Position', [100 100 800 600]);
imagesc(longitude, latitude, xitacr_mean);
colormap(jet(256));
colorbar;
title('Spatial Distribution of xitacr');
xlabel('Longitude');
ylabel('Latitude');
set(gcf, 'Color', 'white');
print('H:\ServerERA\ET2024_Simulation\xitacr_distribution.png', '-dpng', '-r300');
clear xitacr_mean

clear p Field0 diaowei0  % Clear variables no longer needed
fprintf('xitacr calculation completed in %.2f seconds\n\n', toc(step_time));


fprintf('========== Step 5: Calculating fTREW0 and fREW ==========\n');
step_time = tic;

% Calculate fTREW0 in blocks
fprintf('Starting block-wise calculation of fTREW0...\n');
block_size = 300;  % Process 300 longitude points at a time
n_blocks = ceil(3600/block_size);
fTREW0 = zeros(264,1800,3600,'single');  % Pre-allocate memory

for b = 1:n_blocks
    block_time = tic;
    fprintf('Processing fTREW0 data block: %d/%d\n', b, n_blocks);
    
    % Calculate current block range
    start_idx = (b-1)*block_size + 1;
    end_idx = min(b*block_size, 3600);
    curr_slice = start_idx:end_idx;
    
    % Extract current block data
    xitacr_block = xitacr(:,:,curr_slice);
    SM_block = SM(:,:,curr_slice);
    diaoweich_block = diaoweich(:,:,curr_slice);
    
    % Calculate current block's fTREW0
    fTREW0(:,:,curr_slice) = (xitacr_block-SM_block)./(xitacr_block-diaoweich_block);
    
    % Handle boundary conditions for current block
    curr_block = fTREW0(:,:,curr_slice);
    curr_block(curr_block > 1) = 1;
    curr_block(curr_block < 0) = 0;
    curr_block(isnan(curr_block)) = 0;
    fTREW0(:,:,curr_slice) = curr_block;
    
    % Clear temporary variables
    clear xitacr_block SM_block diaoweich_block curr_block
    fprintf('Data block %d processing completed in %.2f seconds\n', b, toc(block_time));
end

% Generate spatial distribution plot for fTREW0 after calculation
fprintf('Generating spatial distribution plot for fTREW0...\n');
fTREW0_mean = squeeze(mean(fTREW0, 1));
figure('Position', [100 100 800 600]);
imagesc(longitude, latitude, fTREW0_mean);
colormap(jet(256));
colorbar;
title('Spatial Distribution of fTREW0');
xlabel('Longitude');
ylabel('Latitude');
set(gcf, 'Color', 'white');
print('H:\ServerERA\ET2024_Simulation\fTREW0_distribution.png', '-dpng', '-r300');
clear fTREW0_mean

clear diaowei0 Field0 xitacr

% Calculate fTREW
fprintf('Calculating fTREW...\n');
fTREW = zeros(264,1800,3600,'single');  % Pre-allocate memory

for b = 1:n_blocks
    block_time = tic;
    fprintf('Processing fTREW data block: %d/%d\n', b, n_blocks);
    
    % Calculate current block range
    start_idx = (b-1)*block_size + 1;
    end_idx = min(b*block_size, 3600);
    curr_slice = start_idx:end_idx;
    
    % Extract current block data
    fTREW0_block = fTREW0(:,:,curr_slice);
    CHsc_block = CHsc(:,:,curr_slice);
    
    % Calculate current block's fTREW
    fTREW(:,:,curr_slice) = 1-(fTREW0_block.^CHsc_block);
    
    % Clear temporary variables
    clear fTREW0_block CHsc_block
    fprintf('Data block %d processing completed in %.2f seconds\n', b, toc(block_time));
end

% Generate spatial distribution plot for fTREW after calculation
fprintf('Generating spatial distribution plot for fTREW...\n');
fTREW_mean = squeeze(mean(fTREW, 1));
figure('Position', [100 100 800 600]);
imagesc(longitude, latitude, fTREW_mean);
colormap(jet(256));
colorbar;
title('Spatial Distribution of fTREW');
xlabel('Longitude');
ylabel('Latitude');
set(gcf, 'Color', 'white');
print('H:\ServerERA\ET2024_Simulation\fTREW_distribution.png', '-dpng', '-r300');
clear fTREW_mean

clear fTREW0 CHsc CH  % Clear variables no longer needed
fprintf('fTREW calculation completed in %.2f seconds\n\n', toc(step_time));

fprintf('========== Step 6: Calculating RHcifang ==========\n');
step_time = tic;
cifang1 = 4.*(1-SM);


% Block reading of fwet data
fprintf('Starting block-wise reading of fwet data...\n');
block_size = 300;  % Process 300 longitude points at a time
n_blocks = ceil(3600/block_size);
fwet = zeros(264,1800,3600,'single');  % Pre-allocate memory

for b = 1:n_blocks
    block_time = tic;
    fprintf('Processing fwet data block: %d/%d\n', b, n_blocks);
    
    % Calculate current block range
    start_idx = (b-1)*block_size + 1;
    end_idx = min(b*block_size, 3600);
    curr_slice = start_idx:end_idx;
    
    % Set reading range
    start_block = [1 1 start_idx];
    count_block = [264 1800 length(curr_slice)];
    
    % Read current block data
    fwet(:,:,curr_slice) = ncread('fwet_2024.nc', 'fwet', start_block, count_block);
    
    fprintf('Data block %d processing completed in %.2f seconds\n', b, toc(block_time));
end



RH = fwet.^(1/4);
cifang = cifang1.*(1-RH);
clear cifang1
cifang(isnan(cifang)) = 0;
RHcifang = RH.^cifang;
clear RH cifang cifang1 SM  % Clear RH related variables

% Generate spatial distribution plot for RHcifang after calculation
fprintf('Generating spatial distribution plot for RHcifang...\n');
RHcifang_mean = squeeze(mean(RHcifang, 1));
figure('Position', [100 100 800 600]);
imagesc(longitude, latitude, RHcifang_mean);
colormap(jet(256));
colorbar;
title('Spatial Distribution of RHcifang');
xlabel('Longitude');
ylabel('Latitude');
set(gcf, 'Color', 'white');
print('H:\ServerERA\ET2024_Simulation\RHcifang_distribution.png', '-dpng', '-r300');
clear RHcifang_mean

fprintf('RHcifang calculation completed in %.2f seconds\n\n', toc(step_time));

fprintf('========== Step 7: Processing FAPAR and APARmax ==========\n');
step_time = tic;

% Block processing of FAPAR data
fprintf('Starting block-wise processing of FAPAR data...\n');
block_size = 50;  % Process 50 time steps at a time
n_blocks = ceil(264/block_size);
FAPAR = zeros(264,1800,3600,'single');  % Pre-allocate memory

for b = 1:n_blocks
    block_time = tic;
    fprintf('Processing FAPAR data block: %d/%d\n', b, n_blocks);
    
    % Calculate current block range
    start_idx = (b-1)*block_size + abc;
    count_size = min(block_size, 264 - (b-1)*block_size);
    
    % Set reading range
    start_block = [abc 1 1] + [(b-1)*block_size 0 0];
    count_block = [count_size 1800 3600];
    
    % Read EVI data for current block
    EVI_block = ncread('EVI_mon2023.nc', 'EVI', start_block, count_block);
    
    % Calculate FAPAR
    idx_start = (b-1)*block_size + 1;
    idx_end = idx_start + count_size - 1;
    FAPAR_block = 1.3632.*EVI_block - 0.048;
    FAPAR_block(FAPAR_block < 0) = 0;
    
    % Store results
    FAPAR(idx_start:idx_end,:,:) = FAPAR_block;
    
    % Clear temporary variables
    clear EVI_block FAPAR_block
    fprintf('Data block %d processing completed in %.2f seconds\n', b, toc(block_time));
end

% Generate spatial distribution plot for FAPAR after calculation
fprintf('Generating spatial distribution plot for FAPAR...\n');
FAPAR_mean = squeeze(mean(FAPAR, 1));
figure('Position', [100 100 800 600]);
imagesc(longitude, latitude, FAPAR_mean);
colormap(jet(256));
colorbar;
title('Spatial Distribution of FAPAR');
xlabel('Longitude');
ylabel('Latitude');
set(gcf, 'Color', 'white');
print('H:\ServerERA\ET2024_Simulation\FAPAR_distribution.png', '-dpng', '-r300');
clear FAPAR_mean

% Optimize APARmax calculation
fprintf('Calculating APARmax...\n');
APARmax = zeros(22,1800,3600,'single');
for i = 1:22
    APARmax(i,:,:) = max(FAPAR(i*12-11:12*i,:,:),[],1);
end

% Vectorized calculation of fm
fprintf('Calculating fm...\n');
fm = nan(264,1800,3600,'single');
for i = 1:264
    fm(i,:,:) = FAPAR(i,:,:)./APARmax(ceil(i/12),:,:);
end
fm(isnan(fm)) = 0;

% Generate spatial distribution plot for APARmax after calculation
fprintf('Generating spatial distribution plot for APARmax...\n');
APARmax_mean = squeeze(mean(APARmax, 1));
figure('Position', [100 100 800 600]);
imagesc(longitude, latitude, APARmax_mean);
colormap(jet(256));
colorbar;
title('Spatial Distribution of APARmax');
xlabel('Longitude');
ylabel('Latitude');
set(gcf, 'Color', 'white');
print('H:\ServerERA\ET2024_Simulation\APARmax_distribution.png', '-dpng', '-r300');
clear APARmax_mean

fprintf('FAPAR and APARmax calculation completed in %.2f seconds\n\n', toc(step_time));

fprintf('========== Step 8: Calculating fTRM ==========\n');
step_time = tic;
fTRM = (1-RHcifang).*fm + RHcifang.*fTREW;
clear RHcifang fTREW fm

% Generate spatial distribution plot for fTRM after calculation
fprintf('Generating spatial distribution plot for fTRM...\n');
fTRM_mean = squeeze(mean(fTRM, 1));
figure('Position', [100 100 800 600]);
imagesc(longitude, latitude, fTRM_mean);
colormap(jet(256));
colorbar;
title('Spatial Distribution of fTRM');
xlabel('Longitude');
ylabel('Latitude');
set(gcf, 'Color', 'white');
print('H:\ServerERA\ET2024_Simulation\fTRM_distribution.png', '-dpng', '-r300');
clear fTRM_mean

fprintf('fTRM calculation completed in %.2f seconds\n\n', toc(step_time));

fprintf('========== Step 9: Calculating fg ==========\n');
step_time = tic;
NDVI(:,:,:)=ncread('NDVI_mon2023.nc','NDVI',start,count);



fg = FAPAR./((1.*NDVI)-0.05);
fg(fg < 0) = 0;
fg(fg > 1) = 1;
fg(isnan(fg)) = 0;

clear FAPAR NDVI
fprintf('fg calculation completed in %.2f seconds\n\n', toc(step_time));

fprintf('========== Step 10: Reading Other Data and Calculating ETc ==========\n');
step_time = tic;

% Set block size
block_size = 300; % Can be adjusted based on actual needs
n_blocks = ceil(3600/block_size);
fprintf('Block size: %d, Total blocks: %d\n', block_size, n_blocks);

% Modify ft data reading
fprintf('Reading ft data...\n');
% First get information about ft data
ft_info = ncinfo('ft2025.nc', 'ft');
fprintf('ft data dimensions: ');
for i = 1:length(ft_info.Size)
    fprintf('%d ', ft_info.Size(i));
end
fprintf('\n');

% Set reading range, adapted to new dimension order [lon lat time]
ft_start = [1 1 1];  % Start from the first element
ft_count = [3600 1800 264];  % Read required dimensions

fprintf('Reading and adjusting ft data dimensions...\n');
ft_temp = ncread('ft2025.nc', 'ft', ft_start, ft_count);
% Adjust dimension order to [time lat lon]
ft = permute(ft_temp, [3 2 1]);
clear ft_temp
fprintf('ft data reading and dimension adjustment completed\n');
% Generate spatial distribution plot for ft after calculation
fprintf('Generating spatial distribution plot for ft...\n');
fTRM_mean = squeeze(mean(ft, 1));
figure('Position', [100 100 800 600]);
imagesc(longitude, latitude, fTRM_mean);
colormap(jet(256));
colorbar;
title('Spatial Distribution of ft');
xlabel('Longitude');
ylabel('Latitude');
set(gcf, 'Color', 'white');
print('H:\ServerERA\ET2024_Simulation\ft_distribution.png', '-dpng', '-r300');


% Block reading of Rnc and delta data
fprintf('Starting block-wise reading of Rnc and delta data...\n');
block_size = 300;  % Process 300 longitude points at a time
n_blocks = ceil(3600/block_size);
Rnc = zeros(264,1800,3600,'single');
delta = zeros(264,1800,3600,'single');

for b = 1:n_blocks
    block_time = tic;
    fprintf('Processing Rnc and delta data block: %d/%d\n', b, n_blocks);
    
    % Calculate current block range
    start_idx = (b-1)*block_size + 1;
    end_idx = min(b*block_size, 3600);
    curr_slice = start_idx:end_idx;
    
    % Set reading range
    start_block = [1 1 start_idx];
    count_block = [264 1800 length(curr_slice)];
    
    % Read current block data
    Rnc(:,:,curr_slice) = ncread('H:\ServerERA\Rnc_mon2024.nc', 'Rnc', start_block, count_block);
    delta(:,:,curr_slice) = ncread('delta_mon2023.nc', 'delta', start_block, count_block);
    
    fprintf('Data block %d processing completed in %.2f seconds\n', b, toc(block_time));
end



fprintf('Rnc and delta data reading completed\n');

% Handle boundary conditions for fwet and ft
fwet(fwet < 0) = 0;
fwet(fwet > 1) = 1;
fwet(isnan(fwet)) = 0;
ft(ft < 0) = 0;
ft(ft > 1) = 1;
ft(isnan(ft)) = 0;
fTRM(fTRM < 0) = 0;
fTRM(fTRM > 1) = 1;
fTRM(isnan(fTRM)) = 0;

% Calculate ETc in blocks
for b = 1:n_blocks
    block_time = tic;
    fprintf('Processing data block: %d/%d (%.1f%%)\n', b, n_blocks, b/n_blocks*100);
    
    % Calculate current block range
    start_idx = (b-1)*block_size + 1;
    end_idx = min(b*block_size, 3600);
    
    % Extract current block data
    curr_slice = start_idx:end_idx;
    fwet_block = fwet(:,:,curr_slice);
    fg_block = fg(:,:,curr_slice);
    ft_block = ft(:,:,curr_slice);
    fTRM_block = fTRM(:,:,curr_slice);
    delta_block = delta(:,:,curr_slice);
    Rnc_block = Rnc(:,:,curr_slice);
    
    % Calculate mask and delta_term
    mask_block = fwet_block < 1;
    delta_term_block = delta_block./(delta_block+0.066).*Rnc_block;
    
    % Calculate current block's ETc
    block_result = zeros(size(mask_block), 'single');
    
    % Calculate true part of mask
    block_result(mask_block) = (1-fwet_block(mask_block)).*...
                              fg_block(mask_block).*...
                              ft_block(mask_block).*...
                              fTRM_block(mask_block).*...
                              1.26.*delta_term_block(mask_block);
    
    % Calculate false part of mask
    block_result(~mask_block) = fwet_block(~mask_block).*...
                               fg_block(~mask_block).*...
                               ft_block(~mask_block).*...
                               fTRM_block(~mask_block).*...
                               1.26.*delta_term_block(~mask_block);
    
    % Store results
    ETc(:,:,curr_slice) = block_result;
    
    % Clear temporary variables after processing a data block
    clear block_result delta_term_block mask_block fwet_block fg_block ft_block fTRM_block delta_block Rnc_block curr_slice
    fprintf('Data block %d processing completed in %.2f seconds\n', b, toc(block_time));
end



clear fg ft Rnc delta fTRM  % Clear variables no longer needed after ETc calculation

% Handle boundary conditions for ETc
fprintf('Handling ETc boundary conditions...\n');
ETc(ETc < 0) = 0;
ETc(isnan(ETc)) = 0;
ETc(ETc > 2000) = 2000;
fprintf('ETc calculation completed in total %.2f seconds\n\n', toc(step_time));

fprintf('========== Step 11: Reading ETs ==========\n');
step_time = tic;

% Read ETs data
fprintf('Reading ETs data...\n');
ETs = ncread('H:\ServerERA\ET2024_Simulation\ETs_mon2025.nc', 'ET');



fprintf('ETs reading completed in %.2f seconds\n\n', toc(step_time));

disp('------------finish ETs-----------');

fprintf('========== Step 12: Processing Landcover and Calculating Final Results ==========\n');
step_time = tic;
 
% Read Ei and Eu data
fprintf('Reading Ei and Eu data...\n');
Ei = ncread('H:\ServerERA\Ei_mon2025.nc', 'Ei');
Eu = ncread('H:\ServerERA\Eu_mon2025.nc', 'Eu');

% Generate spatial distribution plot for ETyr after calculation
fprintf('Generating spatial distribution plot for ETyr...\n');
ETyr_mean = squeeze(mean(Ei, 1));  % Calculate temporal mean
figure('Position', [100 100 800 600]);
imagesc(longitude, latitude, ETyr_mean);
colormap(jet(256));
colorbar;
title('Spatial Distribution of ETyr');
xlabel('Longitude');
ylabel('Latitude');
set(gcf, 'Color', 'white');
print('H:\ServerERA\ET2024_Simulation\Ei_distribution.png', '-dpng', '-r300');

% Calculate ETall
fprintf('Calculating ETall...\n');
ETall = ETc + ETs + Ei + Eu;
% Handle boundary conditions for ETall
ETall(ETall < 0) = 0;
ETall(isnan(ETall)) = 0;
ETall(ETall > 1000) = 1000;
% Calculate annual mean
fprintf('Calculating annual mean...\n');
for i = 1:22
    ETyr(i,:,:) = sum(ETall(i*12-11:12*i,:,:),1);
end
% Read reference data
fprintf('Reading ET2000 reference data...\n');
meanm = ncread('H:\ServerERA\ET2000.nc','ET');

% Create reference mask (true for NaN positions)
mask = isnan(meanm(2:2:end,2:2:end));  % Take every 2nd point, create NaN mask

% Process ETyr data (annual scale)
fprintf('Processing ETyr data...\n');
for k = 1:22  % Process each year separately
    ETyr(k,mask) = NaN;  % Set NaN positions in ETyr to NaN in reference data
end

% Process ETall data (monthly scale)
fprintf('Processing ETall data...\n');
for t = 1:264  % Process each month separately
    ETall(t,mask) = NaN;  % Set NaN positions in ETall to NaN in reference data
end

% Clear temporary variables
clear meanm mask

% Generate spatial distribution plot for ETyr after calculation
fprintf('Generating spatial distribution plot for ETyr...\n');
ETyr_mean = squeeze(mean(ETyr, 1));  % Calculate temporal mean
figure('Position', [100 100 800 600]);
imagesc(longitude, latitude, ETyr_mean);
colormap(jet(256));
colorbar;
title('Spatial Distribution of ETyr');
xlabel('Longitude');
ylabel('Latitude');
set(gcf, 'Color', 'white');
print('H:\ServerERA\ET2024_Simulation\ETyr_distribution.png', '-dpng', '-r300');
clear ETyr_mean

fprintf('ETyr calculation completed in %.2f seconds\n\n', toc(step_time));


%%  OUTPUT
longitude   =0:0.1:359.9;
latitude    =-90:0.1:89.9;
time        =1:1:22;

disp('-------------%%%read data---------------');
 ncid = netcdf.create('H:\ServerERA\ET2024_Simulation\tryET_20002021.nc','CLOBBER'); 
%%%Create variables y atributes
%%%Create dimensiones
  dimid_lon=netcdf.defDim(ncid,'lon',3600);
  dimid_lat=netcdf.defDim(ncid,'lat',1800); 
 dimid_tim=netcdf.defDim(ncid,'time',22);
   disp('-------------define dimension---------------');

%%%Create variables y atributes
   %lon
    varid_lon = netcdf.defVar(ncid,'lon','float',dimid_lon);
    netcdf.putAtt(ncid,varid_lon,'long_name','Longitude');
    netcdf.putAtt(ncid,varid_lon,'units','degrees_east');
    % lat
    varid_lat = netcdf.defVar(ncid,'lat','float',dimid_lat);
    netcdf.putAtt(ncid,varid_lat,'long_name','Latitude');
    netcdf.putAtt(ncid,varid_lat,'units','degrees_north');
    % time
    varid_tim = netcdf.defVar(ncid,'time','float',dimid_tim);
    netcdf.putAtt(ncid,varid_tim,'long_name','Time');
    netcdf.putAtt(ncid,varid_tim,'units','since 200101');
    %variable
    varid_e0 = netcdf.defVar(ncid,'ET','double',[dimid_tim,dimid_lat,dimid_lon]);
    netcdf.putAtt(ncid,varid_e0,'long_name','(ET)')
    netcdf.putAtt(ncid,varid_e0,'units','ET-mon')
    netcdf.putAtt(ncid,varid_e0,'missing_value',32766)%%fine the missing value
    netcdf.endDef(ncid)
    disp('-------------%%%Create variables y atributes---------------');  
     %%% create nc-file

     disp('------------finish al-----------');
   netcdf.putVar(ncid,varid_tim,time);
      netcdf.putVar(ncid,varid_lat,latitude);
      netcdf.putVar(ncid,varid_lon,longitude);
      netcdf.putVar(ncid,varid_e0,ETyr); 
    disp('-------------write data---------------');
   netcdf.close(ncid);
   
%%  OUTPUT
longitude   =0:0.1:359.9;
latitude    =-90:0.1:89.9;
time        =1:1:264;

disp('-------------%%%read data---------------');
 ncid = netcdf.create('H:\ServerERA\ET2024_Simulation\tryET_mon20002021.nc','CLOBBER'); 
%%%Create variables y atributes
%%%Create dimensiones
  dimid_lon=netcdf.defDim(ncid,'lon',3600);
  dimid_lat=netcdf.defDim(ncid,'lat',1800); 
 dimid_tim=netcdf.defDim(ncid,'time',264);
   disp('-------------define dimension---------------');

%%%Create variables y atributes
   %lon
    varid_lon = netcdf.defVar(ncid,'lon','float',dimid_lon);
    netcdf.putAtt(ncid,varid_lon,'long_name','Longitude');
    netcdf.putAtt(ncid,varid_lon,'units','degrees_east');
    % lat
    varid_lat = netcdf.defVar(ncid,'lat','float',dimid_lat);
    netcdf.putAtt(ncid,varid_lat,'long_name','Latitude');
    netcdf.putAtt(ncid,varid_lat,'units','degrees_north');
    % time
    varid_tim = netcdf.defVar(ncid,'time','float',dimid_tim);
    netcdf.putAtt(ncid,varid_tim,'long_name','Time');
    netcdf.putAtt(ncid,varid_tim,'units','since 200101');
    %variable
    varid_e0 = netcdf.defVar(ncid,'ET','double',[dimid_tim,dimid_lat,dimid_lon]);
    netcdf.putAtt(ncid,varid_e0,'long_name','(ET)')
    netcdf.putAtt(ncid,varid_e0,'units','ET-mon')
    netcdf.putAtt(ncid,varid_e0,'missing_value',32766)%%fine the missing value
    netcdf.endDef(ncid)
    disp('-------------%%%Create variables y atributes---------------');  
     %%% create nc-file

     disp('------------finish al-----------');
   netcdf.putVar(ncid,varid_tim,time);
      netcdf.putVar(ncid,varid_lat,latitude);
      netcdf.putVar(ncid,varid_lon,longitude);
      netcdf.putVar(ncid,varid_e0,ETall); 
    disp('-------------write data---------------');
   netcdf.close(ncid);


% Calculate total runtime
total_time = toc(total_start_time);
fprintf('\n========== Program Execution Completed ==========\n');
fprintf('Total time: %.2f seconds (%.2f minutes)\n', total_time, total_time/60);
fprintf('End time: %s\n', datestr(now, 'yyyy-mm-dd HH:MM:SS'));




% Generate spatial distribution plot for ETc after calculation
fprintf('Generating spatial distribution plot for ETc...\n');
ETc_mean = squeeze(mean(ETc, 1));
figure('Position', [100 100 800 600]);
imagesc(longitude, latitude, ETc_mean);
colormap(jet(256));
colorbar;
title('Spatial Distribution of ETc');
xlabel('Longitude');
ylabel('Latitude');
set(gcf, 'Color', 'white');
print('H:\ServerERA\ET2024_Simulation\ETc_distribution.png', '-dpng', '-r300');
clear ETc_mean

% Generate spatial distribution plot for ETs after calculation
fprintf('Generating spatial distribution plot for ETs...\n');
ETs_mean = squeeze(mean(ETs, 1));
figure('Position', [100 100 800 600]);
imagesc(longitude, latitude, ETs_mean);
colormap(jet(256));
colorbar;
title('Spatial Distribution of ETs');
xlabel('Longitude');
ylabel('Latitude');
set(gcf, 'Color', 'white');
print('H:\ServerERA\ET2024_Simulation\ETs_distribution.png', '-dpng', '-r300');
clear ETs_mean

% Generate spatial distribution plot for Ei after calculation
fprintf('Generating spatial distribution plot for Ei...\n');
Ei_mean = squeeze(mean(Ei, 1));
figure('Position', [100 100 800 600]);
imagesc(longitude, latitude, Ei_mean);
colormap(jet(256));
colorbar;
title('Spatial Distribution of Ei');
xlabel('Longitude');
ylabel('Latitude');
set(gcf, 'Color', 'white');
print('H:\ServerERA\ET2024_Simulation\Ei_distribution.png', '-dpng', '-r300');
clear Ei_mean

% Generate spatial distribution plot for Eu after calculation
fprintf('Generating spatial distribution plot for Eu...\n');
Eu_mean = squeeze(mean(Eu, 1));
figure('Position', [100 100 800 600]);
imagesc(longitude, latitude, Eu_mean);
colormap(jet(256));
colorbar;
title('Spatial Distribution of Eu');
xlabel('Longitude');
ylabel('Latitude');
set(gcf, 'Color', 'white');
print('H:\ServerERA\ET2024_Simulation\Eu_distribution.png', '-dpng', '-r300');
clear Eu_mean

% Generate spatial distribution plot for ETall after calculation
fprintf('Generating spatial distribution plot for ETall...\n');
ETall_mean = squeeze(mean(ETall, 1).*12);
figure('Position', [100 100 800 600]);
imagesc(longitude, latitude, ETall_mean);
colormap(jet(256));
colorbar;
title('Spatial Distribution of ETall');
xlabel('Longitude');
ylabel('Latitude');
set(gcf, 'Color', 'white');
print('H:\ServerERA\ET2024_Simulation\ETall_distribution.png', '-dpng', '-r300');
clear ETall_mean


