%This script is a modified version for PTJPLim ETs calculation which
%calculates monthly soil evaporation (ETs) using the PT-JPLim model  
%for global land areas (0.1° resolution) over 2000–2021. 
clear
clc
fprintf('\n========== Starting ETs Calculation Program ==========\n');
fprintf('Start time: %s\n', datestr(now, 'yyyy-mm-dd HH:MM:SS'));

% Define data reading parameters for NetCDF files
abc = (2000-1981)*12-11;
start1 = [1 1 abc]; 
count1 = [3600 1800 264]; 
start = [abc 1 1]; 
count = [264 1800 3600]; 
longitude   =0:0.1:359.9;
latitude    =-90:0.1:89.9;
% Add latitude check code before pre-allocating arrays at file start
fprintf('Pre-allocating memory...\n');

% Check latitude order of input data
fprintf('Checking latitude order of input data...\n');

% Function: Attempt to read latitude data from various variable names
function lat = try_read_latitude(filename)
    try
        lat = ncread(filename, 'latitude');
    catch
        try
            lat = ncread(filename, 'lat');
        catch
            try
                lat = ncread(filename, 'LAT');
            catch
                fprintf('Warning: Unable to read latitude information from %s\n', filename);
                lat = [];
            end
        end
    end
end

% Read latitude information from input files
soil_lat = try_read_latitude('soilwater12023.nc');
if isempty(soil_lat)
    fprintf('Using default south-to-north direction (-90 to 90)\n');
    need_flip = false;
else
    % Check if data needs to be flipped
    need_flip = false;
    if soil_lat(1) < soil_lat(end)  % If latitude is south-to-north (-90 to 90)
        need_flip = true;
        fprintf('Detected input data latitude order as south-to-north, need to flip to north-to-south\n');
    else
        fprintf('Detected input data latitude order as north-to-south, no flip needed\n');
    end
end

% Pre-allocate large arrays for memory efficiency
fprintf('Pre-allocating memory...\n');
SM = zeros(264,1800,3600,'single');
ETs = zeros(264,1800,3600,'single');

%%  -------Start to calculate ETs-------
fprintf('========== Step 1: Reading Soil Moisture Data ==========\n');
step_time = tic;

% Direct reading and processing of data
SM1 = ncread('soilwater12023.nc','swvl1',start1,count1);
SM2 = ncread('soilwater22023.nc','swvl2',start1,count1);
SM3 = ncread('soilwater32023.nc','swvl3',start1,count1);

% Vectorized processing
SM1(SM1 > 1) = 1;
SM2(SM2 > 1) = 1;
SM3(SM3 > 1) = 1;

% Use permute to directly calculate SM
SM = permute(0.07*SM1 + 0.21*SM2 + 0.72*SM3, [3 2 1]);
clear SM1 SM2 SM3
SM(SM(:,:,:)<0)=0;
% Add flip processing after reading data
if need_flip
    SM = flip(SM, 2);  % Flip latitude dimension
end

fprintf('Soil moisture data processing completed in %.2f seconds\n\n', toc(step_time));


   
%%  -------Start to calculate ETs-------
 SM1(:,:,:)=ncread('soilwater12023.nc','swvl1',start1,count1);  
SM2(:,:,:)=ncread('soilwater22023.nc','swvl2',start1,count1);
SM3(:,:,:)=ncread('soilwater32023.nc','swvl3',start1,count1);
SM1(SM1(:,:,:)>1)=1;
SM2(SM2(:,:,:)>1)=1;
SM3(SM3(:,:,:)>1)=1;
SM=zeros(264,1800,3600);

     disp('----Processing soil moisture data-----');
for i=1:264
     for j=1:1800
          for  k=1:3600
             SM(i,j,k)=(SM1(k,1801-j,i).*0.07+SM2(k,1801-j,i).*0.21+SM3(k,1801-j,i).*0.72);
          end
        end
end
clear SM1;
        clear SM2;
        clear SM3;
    % Generate spatial distribution plot for SM after calculation
fprintf('Generating spatial distribution plot for SM...\n');
SM_mean = squeeze(mean(SM, 1));  % Calculate temporal mean
figure('Position', [100 100 800 600]);
imagesc(longitude, latitude, SM_mean);
colormap(jet(256));
colorbar;
title('Spatial Distribution of Soil Moisture (SM)');
xlabel('Longitude');
ylabel('Latitude');
set(gcf, 'Color', 'white');
print('H:\ServerERA\ET2024_Simulation\SM_distribution.png', '-dpng', '-r300');
clear SM_mean  

  % Read wilting point data
     diaowei0 = ncread('Wilting_point_processed.nc','Wilting_point');
    
  Field0=zeros(1,1800,3600);
Field0(1,:,:)=max(SM(:,:,:),[],1);    
% Set minimum value to 0.3 to ensure globally reasonable distribution values
% This prevents unrealistically low field capacity values in arid regions
 Field0(Field0(1,:,:)<0.3)=0.3;
  disp('----Processing wilting point data-----');
 
  clear diaowei01;
  clear diaowei;

% Vectorized calculation of fREW
fprintf('Calculating fREW...\n');

% Calculate valid region mask where denominator is not zero
valid_mask = (Field0(1,:,:) - diaowei0(1,:,:)) ~= 0;

% Expand diaowei0 and Field0 to same dimensions as SM
diaowei0_expanded = repmat(diaowei0, [264 1 1]);
Field0_expanded = repmat(Field0, [264 1 1]);

% Calculate fREW for all time steps at once
fREW = (SM - diaowei0_expanded)./(Field0_expanded - diaowei0_expanded);

% Handle boundary conditions
fREW(fREW < 0) = 0;
fREW(fREW > 1) = 0;
fREW(isnan(fREW)) = 0;

% Set to 0 in invalid regions (where denominator is 0)
fREW = fREW .* repmat(valid_mask, [264 1 1]);

% Generate spatial distribution plot
fprintf('Generating spatial distribution plot for fREW...\n');
fREW_mean = squeeze(mean(fREW, 1));  % Calculate temporal mean
figure('Position', [100 100 800 600]);
imagesc(longitude, latitude, fREW_mean);
colormap(jet(256));
colorbar;
title('Spatial Distribution of fREW');
xlabel('Longitude');
ylabel('Latitude');
set(gcf, 'Color', 'white');
print('H:\ServerERA\ET2024_Simulation\fREW_distribution.png', '-dpng', '-r300');
clear fREW_mean SM 
%%  -------Start to calculate ETs-------
fprintf('========== Step 11: Calculating ETs ==========\n');
step_time = tic;

% Read data, maintaining original dimensions
fprintf('Reading input data...\n');
Rns(:,:,:) = ncread('H:\ServerERA\Rns_mon2024.nc','Rns');
fprintf('Reading Rns data');
G(:,:,:) = ncread('G_mon2024.nc','G',start,count);
fprintf('Reading G data');
fwet(:,:,:)=ncread('fwet_2024.nc','fwet'); 
fprintf('Reading FWET data');
delta = ncread('delta_mon2023.nc','delta',start,count);
fprintf('Reading delta data');
% Set block size
block_size = 200; % Increase block size to reduce loop iterations
n_blocks = ceil(3600/block_size);

% Initialize ETs
ETs = zeros(264,1800,3600,'single');

% Use single-layer loop for block processing
fprintf('Starting block-wise calculation of ETs...\n');
for b = 1:n_blocks
    block_time = tic;
    
    % Calculate current block range
    start_idx = (b-1)*block_size + 1;
    end_idx = min(b*block_size, 3600);
    curr_slice = start_idx:end_idx;
    
    % Extract current block data
    fwet_block = fwet(:,:,curr_slice);
    fREW_block = fREW(:,:,curr_slice);
    delta_block = delta(:,:,curr_slice);
    Rns_block = Rns(:,:,curr_slice);
    G_block = G(:,:,curr_slice);
    
    % Calculate common terms
    rad_term = Rns_block - G_block;
    delta_term = delta_block./(delta_block + 0.066);
    
    % Calculate conditions
    mask = fwet_block > 0.01;
    
    % Calculate results at once
    result = zeros(size(fwet_block), 'single');
    result(mask) = (fwet_block(mask) + (1-fwet_block(mask)).*fREW_block(mask));
    result(~mask) = (fwet_block(~mask) + fwet_block(~mask).*fREW_block(~mask));
    
    % Apply common terms
    result = result .* 1.26 .* delta_term .* rad_term;
    
    % Store results
    ETs(:,:,curr_slice) = result;
    
    % Clear large temporary variables
    clear result rad_term delta_term mask
    fprintf('Data block %d/%d processing completed in %.2f seconds\n', b, n_blocks, toc(block_time));
end

% Handle boundary conditions
ETs(ETs > 300) = 300;
ETs(ETs < 0) = 0;
fprintf('Generating spatial distribution plot for ETs...\n');
SM_mean = squeeze(mean(ETs, 1).*12);  % Calculate temporal mean
SM_mean(SM_mean > 800) = 800;
figure('Position', [100 100 800 600]);
imagesc(longitude, latitude, SM_mean);
colormap(jet(256));
colorbar;
title('Spatial Distribution of ETs');
xlabel('Longitude');
ylabel('Latitude');
set(gcf, 'Color', 'white');
print('H:\ServerERA\ET2024_Simulation\ETs_distribution.png', '-dpng', '-r300');
clear SM_mean  

fprintf('ETs calculation completed in %.2f seconds\n\n', toc(step_time));

disp('------------ETs calculation finished-----------');


%%  OUTPUT
longitude   =0:0.1:359.9;
latitude    =-90:0.1:89.9;
time        =1:1:264;

disp('-------------%%%read data---------------');
ncid = netcdf.create('H:\ServerERA\ET2024_Simulation\ETs_mon2025.nc','CLOBBER'); 
%%%Create variables y atributes
%%%Create dimensiones
dimid_lon=netcdf.defDim(ncid,'lon',3600);
dimid_lat=netcdf.defDim(ncid,'lat',1800); 
dimid_tim=netcdf.defDim(ncid,'time',264);
   disp('-------------define dimension---------------');

%%%Create variables y atributes
   %lon
    varid_lon = netcdf.defVar(ncid,'lon','float',dimid_lon);
    netcdf.putAtt(ncid,varid_lon,'long_name','Longitude');
    netcdf.putAtt(ncid,varid_lon,'units','degrees_east');
    % lat
    varid_lat = netcdf.defVar(ncid,'lat','float',dimid_lat);
    netcdf.putAtt(ncid,varid_lat,'long_name','Latitude');
    netcdf.putAtt(ncid,varid_lat,'units','degrees_north');
    % time
    varid_tim = netcdf.defVar(ncid,'time','float',dimid_tim);
    netcdf.putAtt(ncid,varid_tim,'long_name','Time');
    netcdf.putAtt(ncid,varid_tim,'units','since 200101');
    %variable
    varid_e0 = netcdf.defVar(ncid,'ET','double',[dimid_tim,dimid_lat,dimid_lon]);
    netcdf.putAtt(ncid,varid_e0,'long_name','(ET)')
    netcdf.putAtt(ncid,varid_e0,'units','ET-mon')
    netcdf.putAtt(ncid,varid_e0,'missing_value',32766)%%fine the missing value
    netcdf.endDef(ncid)
    disp('-------------%%%Create variables y atributes---------------');  
     %%% create nc-file

     disp('------------finish al-----------');
   netcdf.putVar(ncid,varid_tim,time);
      netcdf.putVar(ncid,varid_lat,latitude);
      netcdf.putVar(ncid,varid_lon,longitude);
      netcdf.putVar(ncid,varid_e0,ETs); 
    disp('-------------write data---------------');
   netcdf.close(ncid);
   
